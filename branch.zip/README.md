Project Description:
“MyFoodChoice” is an android application with the clearly designed interface that helps user to record and analyse their food intake and the app will be comparing user’s intake with the Australian/Singapore Dietary Guidelines and gives feedback to the users
The project has the following tasks.
The application will use the user information to automatically calculate the best food intake for them. The application required to use advanced Image recognize algorism to help users to record their intake just by taking a photo. The application gives the users some advice about their food intake to helps them to maintain their healthy diet. And some additional function has been provided such as clock in and get rewards, recipe suggestion, food comparison.
The application can be sued by anyone who wants to keeps healthy diets and keep track of their food habits and dietary preferences
Core Technology: PWA (Progressive Web Application)
- Pycharm
- AWS
- Mysql 5.6
-Jquery